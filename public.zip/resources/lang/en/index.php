<?php
    return[
        'Foods recepies' => 'Foods, desserts, cookies recepies',
        'Site teaches you' => 'This site teaches you how to cook',
        'Foods' => 'Foods',
        'Desserts' => 'Desserts',
        'Cookies' => 'Cookies'
    ];
?>
