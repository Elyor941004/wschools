<?php
    return[
        'Foods recepies' => 'Еда, десерты, печенья рецепты',
        'Site teaches you' => 'Этот сайт научит вас делать куки',
        'Foods' => 'Еда',
        'Desserts' => 'Десерты',
        'Cookies' => 'Печенье'
    ];
?>
