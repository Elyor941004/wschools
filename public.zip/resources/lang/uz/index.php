<?php
    return[
         'Foods recepies' => 'Ovqatlar, shirinliklar, pechene retseptlari',
        'Site teaches you' => 'Ushbu sayt sizga pshiriqlar ovqatlar tayyorlashni o\'rgatadi',
        'Foods' => 'Oziq-ovqatlar',
        'Desserts' => 'Pishiriqlar',
        'Cookies' => 'Pishirilgan narsalar'
    ];
?>
