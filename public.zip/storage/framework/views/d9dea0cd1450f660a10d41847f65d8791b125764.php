<?php $__env->startSection('content'); ?>
<div class="container">
    <div>
      <span >Добавит категории</span> <br>
      <a type="button" class="btn btn-success" href="<?php echo e(route('films.create')); ?>">Create</a>
    </div>
    <br>
    <table class="table">
        <thead class="thead-dark">
          <tr>
            <th>Ид</th>
            <th>Филмы</th>
            <th>Жанр</th>
            <th>фотография</th>
            <th>Функции</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="success">
                <td><?php echo e($model->id); ?></td>
                <td><?php echo e($model->name); ?></td>

                 <td><img src="<?php echo e(asset('storage/'.$model->image)); ?>" alt="" height="150px"></td>
                <td>
                  <a href="<?php echo e(route('films.edit', $model->id)); ?>" class="btn btn-success" style="margin-bottom: 4px" type="button">update</a>
                  <form method="post" action="<?php echo e(route('films.destroy', $model->id)); ?>">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                  </form>
                </td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\installed\OpenServer\domains\foods\resources\views/admin/directions/index.blade.php ENDPATH**/ ?>