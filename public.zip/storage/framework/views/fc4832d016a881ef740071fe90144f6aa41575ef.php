<?php $__env->startSection('content'); ?>
    <main>
        <header class="row tm-welcome-section">
            <h2 class="col-12 text-center tm-section-title"><?php echo e(__('index.Foods recepies')); ?></h2>
            <p class="col-12 text-center"><?php echo e(__('index.Site teaches you')); ?></p>
        </header>
        <div class="tm-paging-links">
            <nav>
                <ul>
                    <li class="tm-paging-item"><a href="<?php echo e(route('index', app()->getLocale())); ?>" class="tm-paging-link <?php echo e((request()->is('/'))?'active':''); ?>"><?php echo e(__('index.Foods')); ?></a></li>
                    <li class="tm-paging-item"><a href="<?php echo e(route('desserts', app()->getLocale())); ?>" class="tm-paging-link <?php echo e((request()->is('desserts'))?'active':''); ?>"><?php echo e(__('index.Desserts')); ?></a></li>
                    <li class="tm-paging-item"><a href="<?php echo e(route('cookies', app()->getLocale())); ?>" class="tm-paging-link <?php echo e((request()->is('cookies'))?'active':''); ?>"><?php echo e(__('index.Cookies')); ?></a></li>
                </ul>
            </nav>
        </div>
        <!-- Gallery -->
        <div class="row tm-gallery">
            <!-- gallery page 1 -->
            <?php if(isset($foods)): ?>
                <div class="tm-gallery-page">
                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
                        <a href="<?php echo e(route('food', [app()->getLocale(), $food->id])); ?>">
                            <figure>
                                <img src="<?php echo e(asset('storage/'.$food->image)); ?>" alt="Image" class="img-fluid tm-gallery-img" style="height: 240px !important;"/>
                                <figcaption>
                                    <h4 class="tm-gallery-title"><?php echo e($food->name); ?></h4>
                                    <p class="tm-gallery-description"><?php echo e(\Illuminate\Support\Str::limit($food->text, 60, '...')); ?></p>
                                    <p class="tm-gallery-price"><?php echo e($food->time.' min'); ?></p>
                                </figcaption>
                            </figure>
                        </a>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($foods->links("pagination::bootstrap-4")); ?>

                </div> <!-- gallery page 1 -->
            <?php endif; ?>
            <?php if(isset($desserts)): ?>
                <div class="tm-gallery-page">
                    <?php $__currentLoopData = $desserts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dessert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
                            <a href="<?php echo e(route('food', [app()->getLocale(), $dessert->id])); ?>">
                                <figure>
                                    <img src="<?php echo e(asset('storage/'.$dessert->image)); ?>" alt="Image" class="img-fluid tm-gallery-img"/>
                                    <figcaption>
                                        <h4 class="tm-gallery-title"><?php echo e($dessert->name); ?></h4>
                                        <p class="tm-gallery-description"><?php echo e(\Illuminate\Support\Str::limit($dessert->text, 60, '...')); ?></p>
                                        <p class="tm-gallery-price"><?php echo e($dessert->time.' min'); ?></p>
                                    </figcaption>
                                </figure>
                            <a/>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($desserts->links("pagination::bootstrap-4")); ?>

                </div> <!-- gallery page 3 -->
            <?php endif; ?>
            <?php if(isset($cookies)): ?>
                <div class="tm-gallery-page ">
                <?php $__currentLoopData = $cookies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cookie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('food', [app()->getLocale(), $cookie->id])); ?>">
                        <article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
                            <figure>
                                    <img src="<?php echo e(asset('storage/'.$cookie->image)); ?>" alt="Image" class="img-fluid tm-gallery-img" style="height: 240px !important;"/>
                                <figcaption>
                                    <h4 class="tm-gallery-title"><?php echo e($cookie->name); ?></h4>
                                    <p class="tm-gallery-description"><?php echo e(\Illuminate\Support\Str::limit($cookie->text, 60, '...')); ?></p>
                                    <p class="tm-gallery-price"><?php echo e($cookie->time.' min'); ?></p>
                                </figcaption>
                            </figure>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($cookies->links("pagination::bootstrap-4")); ?>

                </div>
            <?php endif; ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\installed\OpenServer\domains\foods\resources\views/index.blade.php ENDPATH**/ ?>