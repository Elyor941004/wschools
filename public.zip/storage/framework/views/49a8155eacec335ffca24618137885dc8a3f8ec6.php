<?php $__env->startSection('content'); ?>
    <div class="container">
        <main>
            <header class="row tm-welcome-section">
                <h2 class="col-12 text-center tm-section-title"><?php echo e($foods->name); ?></h2>
                <p class="col-12 text-center"><?php echo e($foods->text); ?></p>
            </header>
            <div class="tm-container-inner">
                <div class="row">
                    <div class="tm-history-inner">
                        <div class="tm-history-img tm-history-border">
                            <img src="<?php echo e(asset('storage/'.$foods->image)); ?>" alt="Image" class="img-fluid tm-history-img"/>
                        </div>
                        <div class="tm-history-text">
                            <h4 class="tm-history-title">Recepies</h4>
                            <ol>
                                <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="tm-mb-p"> <?php echo e($ingredient->name); ?> </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                        </div>
                    </div>
                    <div class="directions">
                        <h4 class="tm-history-title">Directions</h4>
                        <ol>
                            <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="tm-mb-p">
                                    <?php echo e($direction->text); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                    </div>
                </div>
            </div>
        </main>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.food', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\installed\OpenServer\domains\foods\resources\views/food.blade.php ENDPATH**/ ?>