<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="<?php echo e(route('ingredients.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul style="list-style: none">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
                <?php echo e($error); ?>

              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>
        <div class="form-group">
            <label for="name">Ингредиенты:</label>
            <input type="text" class="form-control" id="name" placeholder="Ингредиенты:" name="name">
            <label for="food_id">Еда:</label>
            <select class="form-control" name="food_id">
                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option id="janrId" value="<?php echo e($food->id); ?>"><?php echo e($food->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <br>
        <button type="submit" class="btn btn-primary">Create</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\installed\OpenServer\domains\foods\resources\views/admin/ingredients/create.blade.php ENDPATH**/ ?>