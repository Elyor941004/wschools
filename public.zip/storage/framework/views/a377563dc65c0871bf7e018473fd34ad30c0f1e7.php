<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="<?php echo e(route('foods.update', $model->id)); ?>" method="post" enctype="multipart/form-data">
       <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <ul  style="list-style: none">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
                <?php echo e($error); ?>

              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>
      <?php echo method_field('PUT'); ?>
      <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Названия:</label>
            <input type="text" class="form-control" id="name" placeholder="Филм названия:" name="name" value="<?php echo e($model->name); ?>">
            <label for="publication">Текст:</label>
            <input type="text" class="form-control" id="publication" placeholder="публикатция:" name="text"  value="<?php echo e($model->text); ?>">
            <label for="images">Фотография:</label>
            <input type="file" class="form-control" id="images" name="image" value="<?php echo e($model->image); ?>">
            <label for="time">Время готовить:</label>
            <input type="text" class="form-control" id="time" placeholder="публикатция:" name="times" value="<?php echo e($model->time); ?>">
            <label for="tips">Виберите тип:</label>
            <select name="tips" class="form-control" id="tips">
                <?php $__currentLoopData = $type_foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type_food); ?>" <?php echo e($model->tips == $type_food?'selected':''); ?>><?php echo e($type_food); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label> <b>Ингредиенты:</b></label>
            <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="text" class="form-control" id="time" placeholder="публикатция:" name="ingredient[]" value="<?php echo e($ingredient->name); ?>">
                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div id = "ingredient">
            </div>
            <a class="btn btn-success" onclick="addIngredient()">+</a><br>
            <label> <b>Как подготовить:</b></label>
            <?php $__currentLoopData = $directions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="text" class="form-control" id="time" placeholder="публикатция:" name="directions[]" value="<?php echo e($direction->text); ?>">
                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div id = "directions">

            </div>
            <a class="btn btn-success" onclick="addDirections()">+</a>
            <script>
                function addIngredient() {
                    var inputs = document.createElement("input");
                    var br = document.createElement("br");
                    var clas = document.createAttribute("class");
                    var name = document.createAttribute("name");
                    clas.value = "form-control";
                    name.value = "ingredient[]";
                    inputs.setAttributeNode(clas);
                    inputs.setAttributeNode(name);
                    document.getElementById('ingredient').appendChild(inputs);
                    document.getElementById('ingredient').appendChild(br);
                }
                function addDirections() {
                    var inputs = document.createElement("input");
                    var br = document.createElement("br");
                    var clas = document.createAttribute("class");
                    var name = document.createAttribute("name");
                    clas.value = "form-control";
                    name.value = "directions[]";
                    inputs.setAttributeNode(clas);
                    inputs.setAttributeNode(name);
                    document.getElementById('directions').appendChild(inputs);
                    document.getElementById('directions').appendChild(br);
                }
            </script>
        </div>
           <br>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\installed\OpenServer\domains\foods\resources\views/admin/foods/update.blade.php ENDPATH**/ ?>