<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Cooking tutorial</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400" rel="stylesheet" />
    <link href="<?php echo e(asset('css/all.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/templatemo-style.css')); ?>" rel="stylesheet" />
</head>
<body>
<div class="container">
    <div class="placeholder">
        <div class="parallax-window" data-parallax="scroll" data-image-src="<?php echo e(asset('img/2022.jpeg')); ?>">
            <div class="tm-header">
                <div class="row tm-header-inner">
                    <div class="col-md-6 col-12">
                        <div class="tm-site-text-box">
                            <h1 class="tm-site-title">Cooking tutorial</h1>
                            <h6 class="tm-site-description">new cookies' recepies</h6>
                        </div>
                    </div>
                    <nav class="col-md-6 col-12 tm-nav">
                        <ul class="tm-nav-ul" style="color:green">
                            <li class="tm-nav-li"><a href="<?php echo e(route('index', app()->getLocale())); ?>" class="tm-nav-link">Home</a></li>
                            <li class="tm-nav-li"><a href="<?php echo e(route('contact', app()->getLocale())); ?>" class="tm-nav-link">Contact</a></li>
                            <?php if(auth()->guard()->guest()): ?>
                                <?php if(Route::has('login')): ?>
                                    <li class="tm-nav-li">
                                        <a class="tm-nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                    </li>
                                <?php endif; ?>
                                <?php if(Route::has('register')): ?>
                                    <li class="tm-nav-li">
                                        <a class="tm-nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="dropdown">
                                    <a class="tm-nav-link dropdown-toggle" data-toggle="dropdown">
                                        <?php echo e(Auth::user()->name); ?>

                                    </a>
                                    <div class="dropdown-menu">
                                        <?php if(Auth::user()->is_admin == 1): ?>
                                            <a class="dropdown-item" href="<?php echo e(route('foods.index')); ?>">Admin profile</a>
                                        <?php endif; ?>
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Logout')); ?>

                                        </a>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <li class="tm-nav-li" style="color: white">
                                <?php if(app()->getLocale()): ?>
                                    <?php echo e(strtoupper(app()->getLocale())); ?>

                                <?php else: ?>
                                    EN
                                <?php endif; ?>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->yieldContent('content'); ?>
    <footer class="tm-footer text-center">
        <p>Copyright &copy; 2021 Cookies
            | Design: <a rel="nofollow" href="https://templatemo.com">TemplateMo</a></p>
    </footer>
</div>
<script>
    document.querySelector('select').onchange = function() {window.location = this.value}
</script>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/parallax.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH F:\installed\OpenServer\domains\foods\resources\views/layouts/food.blade.php ENDPATH**/ ?>